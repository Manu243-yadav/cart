package com.cg.shopping.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shopping.entities.Carts;
import com.cg.shopping.entities.Products;
import com.cg.shopping.entities.Users;
import com.cg.shopping.exceptions.ResourceNotFoundException;
import com.cg.shopping.repo.CartsRepository;
import com.cg.shopping.repo.ProductsRepository;
import com.cg.shopping.repo.UsersRepository;
import com.cg.shopping.service.CartsService;


@Service
public class CartsServiceImpl implements CartsService {
	
	@Autowired
	private CartsRepository cartsRepository;
	@Autowired
    private UsersRepository usersRepository;
	@Autowired
    private ProductsRepository productsRepository;
	@Override
	public List<Carts> getAll() {
		// TODO Auto-generated method stub
		List<Carts> carts = cartsRepository.findAll();
		return carts;
	}

	@Override
	public Carts getByCartId(Integer id) {
		// TODO Auto-generated method stub
		
		return cartsRepository.getByCartId(id);
	}

	
	@Override
	public Carts addNewCart(Carts cart) {
		  //Check if user exists
//      Optional<Users> user = usersRepository.findById(cart.getUser().getUserId());
//        if (!user.isPresent()) {
//            throw new RuntimeException("User with id " + cart.getUser().getUserId() + " not found");
//        }
//
//        // Check if all products exist
//      //  for (Products product : Carts.getProduct()) {
//            Optional<Products> prod = productsRepository.findById(((Products) cart.getProducts()).getProductId());
//            if (!prod.isPresent()) {
//                throw new RuntimeException("Product with id " + ((Products) cart.getProducts()).getProductId() + " not found");
//            }
		
		 if (cart.getUser() == null) {
	            throw new IllegalArgumentException("User cannot be null");
	        }
	        if (cart.getProduct() == null) {
	            throw new IllegalArgumentException("Product cannot be null");
	        }
	        

		return cartsRepository.save(cart);
	}

	@Override
	public void deleteByCartId(Integer cartId) {
		// TODO Auto-generated method stub
		cartsRepository.deleteById(cartId);
		
	}

	@Override
	public Carts updateProductToCart(Integer cartId, Integer productId) {
//		 public Carts updateCart(Carts cart) {
        Carts cart = cartsRepository.findById(cartId).orElseThrow(()-> new ResourceNotFoundException("cart not found"));

        Products product = productsRepository.findById(productId)
            .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

//        cart.getProduct().add(product);
		
//		if (!cartsRepository.existsById(cart.getCartId())) {
//            throw new IllegalArgumentException("Cart not found with id: " + cart.getCartId());
//        }
        return cartsRepository.save(cart);
   }
    }

