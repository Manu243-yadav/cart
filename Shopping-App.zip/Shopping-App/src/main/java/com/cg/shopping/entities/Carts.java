package com.cg.shopping.entities;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "carts")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Carts {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id")
	private Integer cartId;
	

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
	private Users user;
    
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Products product;
    
    
//    @ManyToMany
//    @JoinTable(
//       name = "cart_products",
//       joinColumns = @JoinColumn(name = "cart_id"),
//        inverseJoinColumns = @JoinColumn(name = "product_id")
//    )
//   private Set<Products> products = new HashSet<>();

    
    @Column(name = "quantity", nullable = false)
	private int quantity;
}

	