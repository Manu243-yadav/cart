package com.cg.shopping.service;

import java.util.List;
import java.util.Optional;

import com.cg.shopping.entities.Products;

public interface ProductsService {
	Products addNewProduct(Products product);
	List<Products> getAllProducts();
	Optional<Products> getProductById(int productId);
	Products updateProduct(int productId, Products productDetails);
	void deleteProduct(int productId);

}
