package com.cg.shopping.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.shopping.entities.Orders;
import com.cg.shopping.entities.Users;

@Repository
public interface OrdersRepository extends JpaRepository<Orders, Integer> {
	Orders findByUser(Users user);
	List<Orders> getOrdersByOrderDate(LocalDateTime orderDate);
//	Orders updateByOrderId(Orders orderId);

}
