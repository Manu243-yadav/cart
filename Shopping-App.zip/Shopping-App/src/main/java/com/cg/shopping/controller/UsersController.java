package com.cg.shopping.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.shopping.entities.Users;
import com.cg.shopping.service.UsersService;

@RestController
@RequestMapping("/users")
public class UsersController {
	
	@Autowired
	private UsersService usersService;
	
	@PostMapping("/add")
	public ResponseEntity<String> addNewUser(@RequestBody Users user){
		usersService.addNewUser(user);
		return new ResponseEntity<>("User added successfully", HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping("/All")
	public ResponseEntity<List<Users>> getAllUsers(){
		List<Users> users = usersService.getAllUsers();
		return ResponseEntity.ok(users);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<Users> getUserById(@PathVariable("userId") int userId){
		Optional<Users> user = usersService.getUserById(userId);
		if(user.isPresent()) {
			return ResponseEntity.ok(user.get());
		} else {
			
		}
		return ResponseEntity.notFound().build();
		
	}
	@GetMapping("/username")
	public ResponseEntity<Users> getUserByUsername(@RequestParam String username){
		Users user = usersService.getUserByUsername(username);
		if(user!= null) {
			return ResponseEntity.ok(user);
		} else {
		return ResponseEntity.notFound().build();
	}

	}
	@GetMapping("/email")
	public ResponseEntity<Users> getUserByEmail(@RequestParam String email){
		Users user = usersService.getUserByEmail(email);
		if(user!=null) {
			return ResponseEntity.ok(user);
		}else {
		return ResponseEntity.notFound().build();
	}
	}
	
	@PutMapping("/{userId}")
	public ResponseEntity<Users> updateUser(@PathVariable int userId, @RequestBody Users userDetails){
		Users updatedUser = usersService.updateUser(userId, userDetails);
		if(updatedUser != null) {
			return ResponseEntity.ok(updatedUser);
		}else {
		return ResponseEntity.notFound().build();
		
	}
	}
	
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable int userId) {
	    try {
	        usersService.deleteUser(userId);
	        return new ResponseEntity<>("User deleted successfully", HttpStatus.ACCEPTED);
	    } catch (Exception e) {
	        return new ResponseEntity<>("Error deleting user: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	

	}
	
}
