package com.cg.shopping.service;

import java.time.LocalDateTime;
import java.util.List;

import com.cg.shopping.entities.Orders;
import com.cg.shopping.entities.Users;

public interface OrdersService {
    Orders createOrder(Orders order);
	 
	List<Orders> getAll();
	Orders getOrdersByUser(Users user);
	List<Orders> getOrdersByOrderDate(LocalDateTime orderDate);
//	Orders updateOrderId(Orders orderId);
	void deleteOrder(int orderId);

	

	

}
