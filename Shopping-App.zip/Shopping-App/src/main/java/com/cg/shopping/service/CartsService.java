package com.cg.shopping.service;

import java.util.List;

import com.cg.shopping.entities.Carts;
import com.cg.shopping.entities.Products;

public interface CartsService {
	List<Carts> getAll();
	Carts getByCartId(Integer cartId);
	Carts addNewCart(Carts cart);
	void deleteByCartId(Integer cartId);
	Carts updateProductToCart(Integer cartId, Integer productId);
//	Carts updateCart(Carts cart);
	

}
