package com.cg.shopping.entities;

import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.Data;



@Entity
@Table(name = "payments")
@Data
public class Payments {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private int paymentId;
 
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Orders order;
 
    @Column(name = "payment_method", nullable = false, length = 50)
    private String paymentMethod;
 
    @Column(name = "payment_date", nullable = false)
    private LocalDateTime paymentDate;
 
    @Column(name = "payment_status", nullable = false, length = 50)
    private String paymentStatus;
 
	   
	}