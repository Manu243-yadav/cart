package com.cg.shopping.controller;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.shopping.entities.Orders;
import com.cg.shopping.entities.Users;
import com.cg.shopping.service.OrdersService;

@RestController
@RequestMapping("/orders")

public class OrdersController {
	
	@Autowired
	private OrdersService ordersService;
	
	@PostMapping("/create")
	public ResponseEntity<String> createOrder(@RequestBody Orders order){
		ordersService.createOrder(order);
		return new ResponseEntity<>("Record created successfully", HttpStatus.CREATED);
		
	}
	
	@GetMapping("/All")
	public ResponseEntity<List<Orders>> getAllOrders(){
	List<Orders> order = ordersService.getAll();
	return ResponseEntity.ok(order);

   }
	@GetMapping("/user/{userId}")
	public ResponseEntity<Orders> getOrdersByUser(@PathVariable Users user){
		Orders order = ordersService.getOrdersByUser(user);
		return ResponseEntity.ok(order);
		
	}
	@GetMapping("/date/{orderDate}")
	public ResponseEntity<List<Orders>> getOrdersByOrderDate(@PathVariable("orderDate") @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime orderDate) {
        // Your logic here LocalDateTime orderDate){
		List<Orders> order = ordersService.getOrdersByOrderDate(orderDate);
		return ResponseEntity.ok(order);
		
	}
	
	@DeleteMapping("/delete/{orderId}")
	public ResponseEntity<String> deleteOrderId(@PathVariable("orderId") int OrderId){
		ordersService.deleteOrder(OrderId);
		return new ResponseEntity<>("orderId deleted succeefully", HttpStatus.ACCEPTED);
		
	}
	
//	@PutMapping("/update/{orderId}")
//	public ResponseEntity<String> updateOrder(@RequestBody Orders orderId){
//	ordersService.updateOrderId(orderId);
//	return new ResponseEntity<>("orderId updated successfully", HttpStatus.ACCEPTED);
//}
}
