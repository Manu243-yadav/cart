package com.cg.shopping.serviceimpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shopping.entities.Orders;
import com.cg.shopping.entities.Users;
import com.cg.shopping.exceptions.ResourceNotFoundException;
import com.cg.shopping.repo.OrdersRepository;
import com.cg.shopping.service.OrdersService;

@Service
public class OrdersServiceImpl implements OrdersService {
	
	@Autowired
	OrdersRepository ordersRepository;

	@Override
	public List<Orders> getAll() {
		
		return ordersRepository.findAll();
	}

	@Override
	public Orders getOrdersByUser(Users user) {
	
		return ordersRepository.findByUser(user);
	}

	@Override
	public List<Orders> getOrdersByOrderDate(LocalDateTime orderDate) {
		
		return ordersRepository.getOrdersByOrderDate(orderDate);
	}

	@Override
	public Orders createOrder(Orders order) {
		// TODO Auto-generated method stub
		return ordersRepository.save(order);
	}

//	@Override
//	public Orders updateOrderId(Orders orderId) {
//	    
//	 return ordersRepository.updateByOrderId(orderId);

	   
	


	@Override
	public void deleteOrder(int orderId) {
		 if (!ordersRepository.existsById(orderId)) {
	            throw new ResourceNotFoundException("Order not found with id: " + orderId);
	        }
	        ordersRepository.deleteById(orderId);
	   
	}

}
