package com.cg.shopping.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.shopping.entities.Carts;

import com.cg.shopping.service.CartsService;


@RestController
@RequestMapping("/carts")
public class CartsController {
	
	@Autowired
	private CartsService cartsService;
	
	@GetMapping("/all")
	public ResponseEntity<List<Carts>> getAllCarts(){
		List<Carts> cart = cartsService.getAll();
		System.out.println("list of carts");
		return ResponseEntity.ok(cart);
	}
	
	@GetMapping("/{cartId}")
	public ResponseEntity<Carts> getCarts(@PathVariable Integer cartId) {
		Carts cart = cartsService.getByCartId(cartId);
		return ResponseEntity.ok(cart);
	}
	
	@PostMapping("/create")
    public ResponseEntity<String> addNewCart(@RequestBody Carts cart) {
        cartsService.addNewCart(cart);
        return new ResponseEntity<>("Record created successfully", HttpStatus.CREATED);
		
	}
	@DeleteMapping("/delete/{cartId}")
    public ResponseEntity<String> deleteCart(@PathVariable Integer cartId) {
        cartsService.deleteByCartId(cartId);
        return new ResponseEntity<>("Cart deleted successfully", HttpStatus.ACCEPTED);
    }
	@PutMapping("/update/{cartId}/{productId}")
	public ResponseEntity<String> updateProductToCart(@PathVariable Integer cartId, @PathVariable Integer productId){
		cartsService.updateProductToCart(cartId, productId);

	
//	@PutMapping("/update/cart")
//	public ResponseEntity<String> updateCart(@RequestBody Carts cart){
//		cartsService.updateCart(cart);
//		
	return new ResponseEntity<>("ProductId updated successfully", HttpStatus.ACCEPTED);
		
}
}	

