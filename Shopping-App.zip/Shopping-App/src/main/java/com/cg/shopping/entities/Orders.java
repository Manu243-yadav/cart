package com.cg.shopping.entities;

import java.time.LocalDateTime;

import com.cg.shopping.entities.Users;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "orders")
@Data

public class Orders {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private int orderId;
 
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;
 
    @Column(name = "order_date", nullable = false)
    private LocalDateTime orderDate;
 
    @Column(name = "total_amount", nullable = false)
    private int totalAmount;
 
}



