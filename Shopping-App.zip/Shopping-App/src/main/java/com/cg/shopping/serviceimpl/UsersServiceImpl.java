package com.cg.shopping.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shopping.entities.Users;
import com.cg.shopping.repo.CartsRepository;
import com.cg.shopping.repo.UsersRepository;
import com.cg.shopping.service.CartsService;
import com.cg.shopping.service.UsersService;

@Service
public class UsersServiceImpl implements UsersService {
	
	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private CartsRepository cartsRepository;

	@Override
	public Users addNewUser(Users user) {
		
		return usersRepository.save(user);
	}

	@Override
	public List<Users> getAllUsers() {
		
		return usersRepository.findAll();
	}

	@Override
	public Optional<Users> getUserById(int userId) {
		
		return usersRepository.findById(userId);
	}

	@Override
	public Users getUserByUsername(String username) {
		
		return usersRepository.findByusername(username);
	}

	@Override
	public Users getUserByEmail(String email) {
		
		return usersRepository.findByEmail(email);
	}

	@Override
	public Users updateUser(int userId, Users userDetails) {
		 Optional<Users> optionalUser = usersRepository.findById(userId);

	        if (optionalUser.isPresent()) {
	            Users user = optionalUser.get();
	            user.setUsername(userDetails.getUsername());
	            user.setEmail(userDetails.getEmail());
	            user.setPasswordHash(userDetails.getPasswordHash());
	            return usersRepository.save(user);
	        } else {
	            return null;
	        }
	}

	@Override
	public void deleteUser(int userId) {
		// Delete related rows in the carts table
        cartsRepository.deleteById(userId);
        
        //delete user
		usersRepository.deleteById(userId);
 
		
	}

}
