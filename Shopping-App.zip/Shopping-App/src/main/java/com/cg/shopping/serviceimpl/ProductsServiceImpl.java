package com.cg.shopping.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shopping.entities.Products;
import com.cg.shopping.repo.ProductsRepository;
import com.cg.shopping.service.ProductsService;

@Service
public class ProductsServiceImpl implements ProductsService {
	
	@Autowired
	ProductsRepository productsRepository;

	@Override
	public Products addNewProduct(Products product) {
		
		return productsRepository.save(product);
	}

	@Override
	public List<Products> getAllProducts() {
		
		return productsRepository.findAll();
	}

	@Override
	public Optional<Products> getProductById(int productId) {
		
		return productsRepository.findById(productId);
	}

	
	@Override
	public Products updateProduct(int productId, Products productDetails) {
    Optional<Products> optionalProduct = productsRepository.findById(productId);
        
        if (optionalProduct.isPresent()) {
            Products product = optionalProduct.get();
            product.setName(productDetails.getName());
            product.setDescription(productDetails.getDescription());
            product.setPrice(productDetails.getPrice());
            product.setStock(productDetails.getStock());
            return productsRepository.save(product);
        } else {
            // Handle product not found case
            
		return null;
	}
	}

	@Override
	public void deleteProduct(int productId) {
		
		productsRepository.existsById(productId);
		
	}

}
