package com.cg.shopping.service;

import java.util.List;
import java.util.Optional;

import com.cg.shopping.entities.Users;

public interface UsersService {
	Users addNewUser(Users user);
	List<Users> getAllUsers();
	Optional<Users> getUserById(int userId);
	Users getUserByUsername(String username);
	Users getUserByEmail(String email);
	Users updateUser(int userId, Users userDetails);
	void deleteUser(int userId);
	

}
