package com.cg.shopping.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.shopping.entities.Products;
import com.cg.shopping.service.ProductsService;

@RestController
@RequestMapping("/products")
public class ProductsController {
	@Autowired
	private ProductsService productsService;
	
	@PostMapping("/add")
	public ResponseEntity<String> addNewProduct(@RequestBody Products products){
		productsService.addNewProduct(products);
		return new ResponseEntity<>("Product added successfully", HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping("/All")
	public ResponseEntity<List<Products>> getAllProducts(){
		List<Products> products = productsService.getAllProducts();
		return ResponseEntity.ok(products) ;
	}
	
	 @GetMapping("/{id}")
    public ResponseEntity<Products> getProductById(@PathVariable int id) {
        Optional<Products> product = productsService.getProductById(id);
        if (product.isPresent()) {
            return ResponseEntity.ok(product.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
	 @PutMapping("/{id}")
	  public ResponseEntity<Products> updateProduct(@PathVariable int id, @RequestBody Products productDetails) {
	      Products updatedProduct = productsService.updateProduct(id, productDetails);
	        if (updatedProduct != null) {
	            return ResponseEntity.ok(updatedProduct);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }
	 @DeleteMapping("/{productId}")
	 public ResponseEntity<String> deleteProduct(@PathVariable int productId){
		 productsService.deleteProduct(productId);
		return new ResponseEntity<>("Product deleted successfully", HttpStatus.ACCEPTED);
		 
	 }
	}


